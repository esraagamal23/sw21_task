function changcolor()
{
let colord=document.getElementById("myinput").value;
    
document.body.style.color=colord;
	
	
}
